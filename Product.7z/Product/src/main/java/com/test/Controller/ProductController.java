package com.test.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.Exception.ProductException;
import com.test.bean.Product;
import com.test.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping("/products")
	public List<Product> getAllProducts() throws ProductException{
		return productService.getAllProducts();
		
	}
	
	/* @RequestMapping(value="/products",method=RequestMethod.POST) */
	@PostMapping("/products")
	public List<Product> addProducts(@RequestBody Product prod) throws ProductException {
		return productService.addProducts(prod);
	}
	
	@DeleteMapping("/products/{id}")
	public List<Product> deleteProducts(@PathVariable int id) throws ProductException{
		return productService.deleteProducts(id);
	}
	
	@PutMapping("/products/update")
	public List<Product> updateProducts(@RequestBody Product prod) throws ProductException{
		return productService.updateProducts(prod);
	}
	
	@GetMapping("/products/{id}")
	public List<Product> getProductById(@PathVariable int id) throws ProductException{
		return productService.getProductById(id);
	}
	
	@GetMapping("/products/category")
	public List<Product> getProductByCategory(@RequestParam String category) throws ProductException{
		return productService.getProductByCategory(category);
	}

}
