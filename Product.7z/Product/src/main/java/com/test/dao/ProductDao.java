package com.test.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.bean.Product;

public interface ProductDao extends JpaRepository<Product, Integer>{

}
