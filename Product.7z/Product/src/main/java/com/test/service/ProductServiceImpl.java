package com.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.test.Exception.ProductException;
import com.test.bean.Product;
import com.test.dao.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProducts() throws ProductException {

		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductException(e.getMessage());

		}

	}

	@Override
	public List<Product> addProducts(Product prod) throws ProductException {
		if (productRepository.existsById(prod.getId())) {
			throw new ProductException("Product with id " + prod.getId() + "already exits");
		}
		productRepository.save(prod);
		return getAllProducts();
	}

	@Override
	public List<Product> deleteProducts(int id) throws ProductException {
		if (!productRepository.existsById(id)) {
			throw new ProductException("Product with id " + id + "doesnot exits");
		}
		productRepository.deleteById(id);
		return getAllProducts();
	}

	@Override
	public List<Product> updateProducts(Product prod) throws ProductException {

		if (productRepository.existsById(prod.getId())) {
			productRepository.save(prod);
			return getAllProducts();
		}
		throw new ProductException("Product with id " + prod.getId() + "doesnot exits");
	}

	@Override
	
	public List<Product> getProductById(int id) throws ProductException {
		
		return productRepository.findProductById(id);
	}

	@Override
	public List<Product> getProductByCategory(String category) throws ProductException {
		
		return productRepository.findProductByCategory(category);
	}
}
