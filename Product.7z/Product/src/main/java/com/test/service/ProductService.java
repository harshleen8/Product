package com.test.service;

import java.util.List;

import com.test.Exception.ProductException;
import com.test.bean.Product;

public interface ProductService {

	List<Product> getAllProducts() throws ProductException;

	List<Product> addProducts(Product prod) throws ProductException;

	List<Product> deleteProducts(int id) throws ProductException;

	List<Product> updateProducts(Product prod) throws ProductException;

	List<Product> getProductById(int id) throws ProductException;
	List<Product> getProductByCategory(String category) throws ProductException;

}
